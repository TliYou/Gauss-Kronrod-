function R = f(x)
    global n
    R = atan(100*x);
    n= n+1; 
end