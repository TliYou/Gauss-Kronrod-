global n;
n = 0;
a = -1;
b = pi;
tau = 10^-12;
I1 = adaptGaussKron(@f,a,b,tau);